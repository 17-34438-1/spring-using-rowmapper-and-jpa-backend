package com.cpatos.edo.service.sparcsn4;

import java.util.List;

public interface VesselTransitWayService {

    public List getVesselTransitWay(String rotation);
}
