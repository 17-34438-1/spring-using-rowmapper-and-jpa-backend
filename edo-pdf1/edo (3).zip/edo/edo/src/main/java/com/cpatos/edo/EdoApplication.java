package com.cpatos.edo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdoApplication.class, args);
	}

}
