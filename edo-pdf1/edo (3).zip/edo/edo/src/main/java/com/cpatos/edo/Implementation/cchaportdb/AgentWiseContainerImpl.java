package com.cpatos.edo.Implementation.cchaportdb;
import com.cpatos.edo.payload.AgentWiseContainer;
import com.cpatos.edo.payload.ResponseMessage;
import com.cpatos.edo.repository.cchaportdb.AgentWiseContainerRepository;
import com.cpatos.edo.service.cchaportdb.AgentWiseContainerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AgentWiseContainerImpl implements AgentWiseContainerService {
    ResponseMessage responseMessage;

    @Autowired
    AgentWiseContainerRepository agentWiseContainerInfo;

    @Override
    public List getAgentWiseContainer(String serch_by, String serch_value) {
        ArrayList<AgentWiseContainer> arrayList = new ArrayList<>();

        System.out.println("serch_by :" + serch_by);
        System.out.println("serch_value :" + serch_value);

        if (serch_by.equals("rot")) {

            String rotation = serch_value.replace("_", "/");
            System.out.println("rotation :" + rotation);
            List rsltAgentList[] = agentWiseContainerInfo.getAgentContainerByRotation(rotation);

            for (int i = 0; i < rsltAgentList.length; i++) {
                AgentWiseContainer agentWiseContainer = new AgentWiseContainer();

                if (rsltAgentList[i].get(0) != null) {
                    agentWiseContainer.setCont_id(rsltAgentList[i].get(0).toString());
                }
                if (rsltAgentList[i].get(1) != null) {
                    agentWiseContainer.setRotation(rsltAgentList[i].get(1).toString());
                }
                if (rsltAgentList[i].get(2) != null) {
                    agentWiseContainer.setCont_status(rsltAgentList[i].get(2).toString());
                }
                if (rsltAgentList[i].get(3) != null) {
                    agentWiseContainer.setCont_mlo(rsltAgentList[i].get(3).toString());
                }
                if (rsltAgentList[i].get(4) != null) {
                    agentWiseContainer.setCont_size(rsltAgentList[i].get(4).toString());
                }
                if (rsltAgentList[i].get(5) != null) {
                    agentWiseContainer.setCont_height(rsltAgentList[i].get(5).toString());
                }
                if (rsltAgentList[i].get(6) != null) {
                    agentWiseContainer.setAgent(rsltAgentList[i].get(6).toString());
                }
                if (rsltAgentList[i].get(7) != null) {
                    agentWiseContainer.setTransOp(rsltAgentList[i].get(7).toString());
                }

                arrayList.add(agentWiseContainer);
            }
          }

        else if (serch_by.equals("cont")) {


            List rsltAgentList[] = agentWiseContainerInfo.getAgentContainerByContid(serch_value);

            for (int i = 0; i < rsltAgentList.length; i++) {
                AgentWiseContainer agentWiseContainer = new AgentWiseContainer();

                if (rsltAgentList[i].get(0) != null) {
                    agentWiseContainer.setCont_id(rsltAgentList[i].get(0).toString());
                }
                if (rsltAgentList[i].get(1) != null) {
                    agentWiseContainer.setRotation(rsltAgentList[i].get(1).toString());
                }
                if (rsltAgentList[i].get(2) != null) {
                    agentWiseContainer.setCont_status(rsltAgentList[i].get(2).toString());
                }
                if (rsltAgentList[i].get(3) != null) {
                    agentWiseContainer.setCont_mlo(rsltAgentList[i].get(3).toString());
                }
                if (rsltAgentList[i].get(4) != null) {
                    agentWiseContainer.setCont_size(rsltAgentList[i].get(4).toString());
                }
                if (rsltAgentList[i].get(5) != null) {
                    agentWiseContainer.setCont_height(rsltAgentList[i].get(5).toString());
                }
                if (rsltAgentList[i].get(6) != null) {
                    agentWiseContainer.setAgent(rsltAgentList[i].get(6).toString());
                }
                if (rsltAgentList[i].get(7) != null) {
                    agentWiseContainer.setTransOp(rsltAgentList[i].get(7).toString());
                }
                arrayList.add(agentWiseContainer);
            }
        }


        else if (serch_by.equals("mlo")) {
            List rsltAgentList[] = agentWiseContainerInfo.getAgentContainerByContMlo(serch_value);

            for (int i = 0; i < rsltAgentList.length; i++) {
                AgentWiseContainer agentWiseContainer = new AgentWiseContainer();

                if (rsltAgentList[i].get(0) != null) {
                    agentWiseContainer.setCont_id(rsltAgentList[i].get(0).toString());
                }
                if (rsltAgentList[i].get(1) != null) {
                    agentWiseContainer.setRotation(rsltAgentList[i].get(1).toString());
                }
                if (rsltAgentList[i].get(2) != null) {
                    agentWiseContainer.setCont_status(rsltAgentList[i].get(2).toString());
                }
                if (rsltAgentList[i].get(3) != null) {
                    agentWiseContainer.setCont_mlo(rsltAgentList[i].get(3).toString());
                }
                if (rsltAgentList[i].get(4) != null) {
                    agentWiseContainer.setCont_size(rsltAgentList[i].get(4).toString());
                }
                if (rsltAgentList[i].get(5) != null) {
                    agentWiseContainer.setCont_height(rsltAgentList[i].get(5).toString());
                }
                if (rsltAgentList[i].get(6) != null) {
                    agentWiseContainer.setAgent(rsltAgentList[i].get(6).toString());
                }
                if (rsltAgentList[i].get(7) != null) {
                    agentWiseContainer.setTransOp(rsltAgentList[i].get(7).toString());
                }
                arrayList.add(agentWiseContainer);
            }
        }

        else if (serch_by.equals("pod")) {

            List rsltAgentList[] = agentWiseContainerInfo.getAgentContainerByPod(serch_value);

            for (int i = 0; i < rsltAgentList.length; i++) {
                AgentWiseContainer agentWiseContainer = new AgentWiseContainer();

                if (rsltAgentList[i].get(0) != null) {
                    agentWiseContainer.setCont_id(rsltAgentList[i].get(0).toString());
                }
                if (rsltAgentList[i].get(1) != null) {
                    agentWiseContainer.setRotation(rsltAgentList[i].get(1).toString());
                }
                if (rsltAgentList[i].get(2) != null) {
                    agentWiseContainer.setCont_status(rsltAgentList[i].get(2).toString());
                }
                if (rsltAgentList[i].get(3) != null) {
                    agentWiseContainer.setCont_mlo(rsltAgentList[i].get(3).toString());
                }
                if (rsltAgentList[i].get(4) != null) {
                    agentWiseContainer.setCont_size(rsltAgentList[i].get(4).toString());
                }
                if (rsltAgentList[i].get(5) != null) {
                    agentWiseContainer.setCont_height(rsltAgentList[i].get(5).toString());
                }
                if (rsltAgentList[i].get(6) != null) {
                    agentWiseContainer.setAgent(rsltAgentList[i].get(6).toString());
                }
                if (rsltAgentList[i].get(7) != null) {
                    agentWiseContainer.setTransOp(rsltAgentList[i].get(7).toString());
                }
                arrayList.add(agentWiseContainer);
            }
        }
        else{

            List rsltAgentList[] = agentWiseContainerInfo.getAgentContainerByTransOp(serch_value);

            for (int i = 0; i < rsltAgentList.length; i++) {
                AgentWiseContainer agentWiseContainer = new AgentWiseContainer();

                if (rsltAgentList[i].get(0) != null) {
                    agentWiseContainer.setCont_id(rsltAgentList[i].get(0).toString());
                }
                if (rsltAgentList[i].get(1) != null) {
                    agentWiseContainer.setRotation(rsltAgentList[i].get(1).toString());
                }
                if (rsltAgentList[i].get(2) != null) {
                    agentWiseContainer.setCont_status(rsltAgentList[i].get(2).toString());
                }
                if (rsltAgentList[i].get(3) != null) {
                    agentWiseContainer.setCont_mlo(rsltAgentList[i].get(3).toString());
                }
                if (rsltAgentList[i].get(4) != null) {
                    agentWiseContainer.setCont_size(rsltAgentList[i].get(4).toString());
                }
                if (rsltAgentList[i].get(5) != null) {
                    agentWiseContainer.setCont_height(rsltAgentList[i].get(5).toString());
                }
                if (rsltAgentList[i].get(6) != null) {
                    agentWiseContainer.setAgent(rsltAgentList[i].get(6).toString());
                }
                if (rsltAgentList[i].get(7) != null) {
                    agentWiseContainer.setTransOp(rsltAgentList[i].get(7).toString());
                }
                arrayList.add(agentWiseContainer);
            }
        }
        return arrayList;

    }


}
