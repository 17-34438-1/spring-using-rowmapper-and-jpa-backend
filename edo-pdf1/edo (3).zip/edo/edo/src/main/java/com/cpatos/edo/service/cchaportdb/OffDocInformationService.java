package com.cpatos.edo.service.cchaportdb;

import com.cpatos.edo.model.cchaportdb.OffDoc;

import java.util.List;

public interface OffDocInformationService {
    //Raifq
    public List<OffDoc> getOffDocList();
}
