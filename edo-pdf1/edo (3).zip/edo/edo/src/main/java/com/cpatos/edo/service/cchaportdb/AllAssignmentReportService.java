package com.cpatos.edo.service.cchaportdb;

import java.util.List;

public interface AllAssignmentReportService {
    public List AllAssignmentReport(String from_date);
}
