package com.cpatos.edo.service.cchaportdb;

import com.cpatos.edo.model.cchaportdb.CommudityDetail;

import java.util.List;

public interface CommudityDetailService {
    //Raifq
    public List<CommudityDetail> getCommydityList();
}
