package com.cpatos.edo.payload;

import lombok.Data;

@Data
public class DeliveryOrder {


    String BL_NO;
    String Pack_Marks_Number;
    String Pack_Number;
    String Pack_Description;
    String Description_of_Goods;
    String weight;
    String weight_unit;
    String cont_number;
    String cont_size;
    String cont_status;

}
