package com.cpatos.edo.service.cchaportdb;

import java.util.List;

public interface EdoContainerService {
    public List edoContainerReport(String from_date,String to_date);
}
