package com.cpatos.edo.Implementation.sparcsn4;

import com.cpatos.edo.payload.MloWisePreAdvisedContainer;
import com.cpatos.edo.payload.ResponseMessage;
import com.cpatos.edo.payload.VesselTransitWay;
import com.cpatos.edo.repository.sparcsn4.MloWisePreAdvisedContainerRepository;
import com.cpatos.edo.service.sparcsn4.MloWisePreAdvisedContainerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class MloWisePreAdvisedContainerServiceImpl implements MloWisePreAdvisedContainerService {
    ResponseMessage responseMessage;

    @Autowired
    MloWisePreAdvisedContainerRepository mloWisePreAdvisedContainerRepository;
    @Override
    public List getMloWisePreAdvisedContainer(String rotation) {
        ArrayList<MloWisePreAdvisedContainer> arrayList = new ArrayList<>();
        String rot = rotation.replace("_", "/");
        System.out.println("rotation :" + rotation);


        List rsltPreAdvisedContainer[] = mloWisePreAdvisedContainerRepository.getMloWisePreAdvisedContainer(rot);
        for (int i = 0; i < rsltPreAdvisedContainer.length; i++) {
            MloWisePreAdvisedContainer mloWisePreAdvisedContainer = new MloWisePreAdvisedContainer();

            if (rsltPreAdvisedContainer[i].get(0) != null) {
                mloWisePreAdvisedContainer.setMLO(rsltPreAdvisedContainer[i].get(0).toString());
            }
            if (rsltPreAdvisedContainer[i].get(1) != null) {
                mloWisePreAdvisedContainer.setAGENT(rsltPreAdvisedContainer[i].get(1).toString());
            }
            if (rsltPreAdvisedContainer[i].get(2) != null) {
                mloWisePreAdvisedContainer.setLOADED_20(rsltPreAdvisedContainer[i].get(2).toString());
            }
            if (rsltPreAdvisedContainer[i].get(3) != null) {
                mloWisePreAdvisedContainer.setLOADED_40(rsltPreAdvisedContainer[i].get(3).toString());
            }
            if (rsltPreAdvisedContainer[i].get(4) != null) {
                mloWisePreAdvisedContainer.setEMTY_20(rsltPreAdvisedContainer[i].get(4).toString());
            }
            if (rsltPreAdvisedContainer[i].get(5) != null) {
                mloWisePreAdvisedContainer.setEMTY_40(rsltPreAdvisedContainer[i].get(5).toString());
            }
            if (rsltPreAdvisedContainer[i].get(6) != null) {
                mloWisePreAdvisedContainer.setREEFER_20(rsltPreAdvisedContainer[i].get(6).toString());
            }
            if (rsltPreAdvisedContainer[i].get(7) != null) {
                mloWisePreAdvisedContainer.setREEFER_40(rsltPreAdvisedContainer[i].get(7).toString());
            }
            if (rsltPreAdvisedContainer[i].get(8) != null) {
                mloWisePreAdvisedContainer.setIMDG_20(rsltPreAdvisedContainer[i].get(8).toString());
            }
            if (rsltPreAdvisedContainer[i].get(9) != null) {
                mloWisePreAdvisedContainer.setIMDG_40(rsltPreAdvisedContainer[i].get(9).toString());
            }
            if (rsltPreAdvisedContainer[i].get(10) != null) {
                mloWisePreAdvisedContainer.setTRSHP_20(rsltPreAdvisedContainer[i].get(10).toString());
            }
            if (rsltPreAdvisedContainer[i].get(11) != null) {
                mloWisePreAdvisedContainer.setTRSHP_40(rsltPreAdvisedContainer[i].get(11).toString());
            }
            if (rsltPreAdvisedContainer[i].get(12) != null) {
                mloWisePreAdvisedContainer.setICD_20(rsltPreAdvisedContainer[i].get(12).toString());
            }
            if (rsltPreAdvisedContainer[i].get(13) != null) {
                mloWisePreAdvisedContainer.setICD_40(rsltPreAdvisedContainer[i].get(13).toString());
            }
            if (rsltPreAdvisedContainer[i].get(14) != null) {
                mloWisePreAdvisedContainer.setLD_20(rsltPreAdvisedContainer[i].get(14).toString());
            }
            if (rsltPreAdvisedContainer[i].get(15) != null) {
                mloWisePreAdvisedContainer.setLD_40(rsltPreAdvisedContainer[i].get(15).toString());
            }
            if (rsltPreAdvisedContainer[i].get(16) != null) {
                mloWisePreAdvisedContainer.setGRAND_TOT(rsltPreAdvisedContainer[i].get(16).toString());
            }
            arrayList.add(mloWisePreAdvisedContainer);
        }
        return arrayList;
    }



}
