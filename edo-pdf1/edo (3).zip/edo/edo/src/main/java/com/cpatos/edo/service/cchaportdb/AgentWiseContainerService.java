package com.cpatos.edo.service.cchaportdb;


import java.util.List;

public interface AgentWiseContainerService {
    //Raifq
    public List getAgentWiseContainer(String serch_by,String serch_value);
}
