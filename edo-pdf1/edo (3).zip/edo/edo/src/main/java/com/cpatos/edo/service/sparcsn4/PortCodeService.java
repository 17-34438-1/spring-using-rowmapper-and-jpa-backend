package com.cpatos.edo.service.sparcsn4;



import java.util.List;

public interface PortCodeService {
    //Raifq
    public List getPortCodeList();
}
