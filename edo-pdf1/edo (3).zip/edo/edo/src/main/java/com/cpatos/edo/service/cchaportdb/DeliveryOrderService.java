package com.cpatos.edo.service.cchaportdb;

import java.util.List;

public interface DeliveryOrderService {
    public List getDeliveryOrder(String bill_entry);
}
