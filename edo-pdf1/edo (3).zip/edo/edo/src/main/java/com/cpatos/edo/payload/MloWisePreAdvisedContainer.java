package com.cpatos.edo.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MloWisePreAdvisedContainer {

		String MLO;
		String AGENT;
		String LOADED_20;
		String LOADED_40;
		String EMTY_20;
		String EMTY_40;
		String REEFER_20;
		String REEFER_40;
		String IMDG_20;
		String IMDG_40;
		String TRSHP_20;
		String TRSHP_40;
		String ICD_20;
		String ICD_40;
		String LD_20;
		String LD_40;
		String GRAND_TOT;
}
