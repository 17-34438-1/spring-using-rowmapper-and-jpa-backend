package com.cpatos.edo.service.sparcsn4;

import java.util.List;

public interface AgentService {
    public List getAgentList();
    public List getAgentWiseVessel(String rotation);
}
