package com.cpatos.edo.controller;

import com.cpatos.edo.model.cchaportdb.CommudityDetail;
import com.cpatos.edo.model.cchaportdb.OffDoc;
import com.cpatos.edo.service.cchaportdb.*;
import com.cpatos.edo.service.sparcsn4.AgentService;
import com.cpatos.edo.service.sparcsn4.PortCodeService;
import com.cpatos.edo.service.sparcsn4.VesselTransitWayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/report")
public class ReportController {
    @Autowired
    OffDocInformationService offDocInformationService;

    @Autowired
    CommudityDetailService commudityDetailService;

    @Autowired
    PortCodeService portCodeService;

    @Autowired
    AgentService agentService;


    @Autowired
    AgentWiseContainerService agentWiseContainerService;


    @Autowired
    OffDocWiseContainerService offDocWiseContainerService;

    @Autowired
    VesselTransitWayService vesselTransitWayService;

    @Autowired
    DeliveryOrderService deliveryOrderService;

    //Rafiq
    @RequestMapping(value = "/OffDocInformation", method = RequestMethod.GET)
    public @ResponseBody
    List<OffDoc> OffDocInfo(){
        return offDocInformationService.getOffDocList();
    }


    //Rafiq
    @RequestMapping(value = "/CommudityInformation", method = RequestMethod.GET)
    public @ResponseBody
    List<CommudityDetail> CommudityInfo(){
        return commudityDetailService.getCommydityList();
    }

    // Rafiq
    @RequestMapping(value = "/PortCodeInfo", method = RequestMethod.GET)
    public @ResponseBody
    List PortCode(){
        return portCodeService.getPortCodeList();
    }

    //Rafiq
    @RequestMapping(value = "/AgentWiseVessel", method = RequestMethod.GET)
    public @ResponseBody
    List AgentList(){
        return agentService.getAgentList();
    }

    //Rafiq
    @RequestMapping(value = "/AgentWiseVesselList/{rotation}", method = RequestMethod.GET)
    public @ResponseBody
    List AgentWiseVessel(@PathVariable String rotation){
        return agentService.getAgentWiseVessel(rotation);
    }


    //Rafiq
    @RequestMapping(value = "/OffDocWiseContainer/{rotation}", method = RequestMethod.GET)
    public @ResponseBody
    List OffDocWiseContainerList( @PathVariable String rotation){
        return offDocWiseContainerService.getOffDocWiseContainer(rotation);
    }

    //Rafiq
    @RequestMapping(value = "/AgentWiseContainer/{serch_by}/{serch_value}", method = RequestMethod.GET)
    public @ResponseBody
    List AgentWiseContainerList( @PathVariable String serch_by ,@PathVariable String serch_value){
        return agentWiseContainerService.getAgentWiseContainer(serch_by,serch_value);
    }

    //Rafiq
    @RequestMapping(value = "/VesselTransitWay/{rotation}", method = RequestMethod.GET)
    public @ResponseBody
    List VesselTransitWay( @PathVariable String rotation){
        return vesselTransitWayService.getVesselTransitWay(rotation);
    }


    //Rafiq
    @RequestMapping(value = "/deliveryOrder/{bill_entry}", method = RequestMethod.GET)
    public @ResponseBody
    List DeliveryOrder(@PathVariable String bill_entry){
        return deliveryOrderService.getDeliveryOrder(bill_entry);
    }




}
