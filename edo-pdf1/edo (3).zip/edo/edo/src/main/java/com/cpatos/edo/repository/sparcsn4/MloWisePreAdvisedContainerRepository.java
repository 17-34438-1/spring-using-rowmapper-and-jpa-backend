package com.cpatos.edo.repository.sparcsn4;

import com.cpatos.edo.model.sparcsn4.ActiveMqLock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MloWisePreAdvisedContainerRepository extends JpaRepository<ActiveMqLock,String> {
    @Query(value ="SELECT mlo,agent,\n" +
            "NVL(SUM(Loaded_20),0) AS Loaded_20,\n" +
            "NVL(SUM(Loaded_40),0) AS Loaded_40,\n" +
            "NVL(SUM(EMTY_20),0) AS EMTY_20,\n" +
            "NVL(SUM(EMTY_40),0) AS EMTY_40,\n" +
            "NVL(SUM(REEFER_20),0) AS REEFER_20,\n" +
            "NVL(SUM(REEFER_40),0) AS REEFER_40,\n" +
            "NVL(SUM(IMDG_20),0) AS IMDG_20,\n" +
            "NVL(SUM(IMDG_40),0) AS IMDG_40,\n" +
            "NVL(SUM(TRSHP_20),0) AS TRSHP_20,\n" +
            "NVL(SUM(TRSHP_40),0) AS TRSHP_40,\n" +
            "NVL(SUM(ICD_20),0) AS ICD_20,\n" +
            "NVL(SUM(ICD_40),0) AS ICD_40,\n" +
            "NVL(SUM(LD_20),0) AS LD_20,\n" +
            "NVL(SUM(LD_40),0) AS LD_40,\n" +
            "NVL(SUM(grand_tot),0) AS grand_tot,\n" +
            "NVL(SUM(tues),0) AS tues\n" +
            "FROM (\n" +
            "SELECT DISTINCT inv_unit.gkey AS gkey,g.id AS mlo,Y.id AS agent,vsl_vessel_visit_details.ib_vyg,\n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) =20  AND inv_unit.freight_kind IN ('FCL','LCL') and ref_equip_type.id not in('22R1','45R1','45R0','25R1','45R3','22R0','42R1','45R8','20R1','22R9','42R0','22R2','20R0','45R4','22R7','42R3','45R5') THEN 1  \n" +
            "ELSE NULL END) AS Loaded_20, \n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) !=20  AND inv_unit.freight_kind IN ('FCL','LCL') and ref_equip_type.id not in('22R1','45R1','45R0','25R1','45R3','22R0','42R1','45R8','20R1','22R9','42R0','22R2','20R0','45R4','22R7','42R3','45R5')  THEN 1  \n" +
            "ELSE NULL END) AS Loaded_40, \n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) = 20 AND inv_unit.freight_kind ='MTY'  THEN 1  \n" +
            "ELSE NULL END) AS EMTY_20, \n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) != 20 AND inv_unit.freight_kind ='MTY'  THEN 1  \n" +
            "ELSE NULL END) AS EMTY_40, \n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) = 20 AND inv_unit.freight_kind IN ('FCL','LCL') AND ref_equip_type.id in('22R1','45R1','45R0','25R1','45R3','22R0','42R1','45R8','20R1','22R9','42R0','22R2','20R0','45R4','22R7','42R3','45R5')  THEN 1  \n" +
            "ELSE NULL END) AS REEFER_20, \n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) != 20 AND inv_unit.freight_kind IN ('FCL','LCL') AND ref_equip_type.id in('22R1','45R1','45R0','25R1','45R3','22R0','42R1','45R8','20R1','22R9','42R0','22R2','20R0','45R4','22R7','42R3','45R5')  THEN 1  \n" +
            "ELSE NULL END) AS REEFER_40,\n" +
            "'' AS IMDG_20, \n" +
            "'' AS IMDG_40, \n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) =20  AND inv_unit.freight_kind IN ('FCL','LCL','MTY') AND inv_unit.category='TRSHP' THEN 1  \n" +
            "ELSE NULL END) AS TRSHP_20, \n" +
            "(CASE WHEN substr(ref_equip_type.nominal_length,-2) !=20  AND inv_unit.freight_kind IN ('FCL','LCL','MTY') AND inv_unit.category='TRSHP' THEN 1  \n" +
            "ELSE NULL END) AS TRSHP_40, \n" +
            "'' AS ICD_20, \n" +
            "'' AS ICD_40, \n" +
            "'' AS LD_20, \n" +
            "'' AS LD_40, \n" +
            "1 AS grand_tot,\n" +
            " (CASE WHEN substr(ref_equip_type.nominal_length,-2) =20  THEN 1 ELSE 2 END) AS tues \n" +
            "FROM  inv_unit\n" +
            "inner join inv_unit_fcy_visit on inv_unit_fcy_visit.unit_gkey=inv_unit.gkey\n" +
            "INNER JOIN ( ref_bizunit_scoped g LEFT JOIN ( ref_agent_representation X LEFT JOIN ref_bizunit_scoped Y ON X.agent_gkey=Y.gkey ) ON g.gkey=X.bzu_gkey ) ON g.gkey = inv_unit.line_op\n" +
            "inner join argo_carrier_visit on argo_carrier_visit.gkey=inv_unit_fcy_visit.actual_ob_cv\n" +
            "inner join vsl_vessel_visit_details on vsl_vessel_visit_details.vvd_gkey=argo_carrier_visit.cvcvd_gkey\n" +
            "INNER JOIN ref_equipment ON ref_equipment.gkey=inv_unit.eq_gkey\n" +
            "INNER JOIN ref_equip_type ON ref_equip_type.gkey=ref_equipment.eqtyp_gkey\n" +
            "WHERE  vsl_vessel_visit_details.ib_vyg=:rotation\n" +
            ") tmp GROUP BY mlo,agent ",nativeQuery = true)
    List[] getMloWisePreAdvisedContainer(@Param("rotation") String rotation);

}
