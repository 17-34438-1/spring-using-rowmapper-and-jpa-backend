package com.cpatos.edo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdoApplicationTests {

	@Test
	void contextLoads() {
	}

}
